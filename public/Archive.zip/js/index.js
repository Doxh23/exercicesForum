import bootstrap from "./bootstrap";
import "../sass/screen.scss";

bootstrap();