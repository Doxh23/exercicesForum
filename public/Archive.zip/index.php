<?php
    session_start();
    error_reporting(0);
    require_once '../app/require.php';
    
?>